#!/usr/bin/env python3
"""Validate the published N4 commit in an independent clone; never deploy it.

Python standard library only. Native Rust commands execute through owned process
handles. D0/N3 are read-only evidence, not commands to rerun. No source patch,
reset, clean, branch update, installation, or broad process-name termination.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time
from datetime import datetime, timezone
import zipfile

VERSION = "N4-EXACT-RECOVERY-2.0"
REPOSITORY = "https://github.com/yaelkroy/MechoFly.git"
CANDIDATE = "6b67b6f8678151f1e568ebfb84ac773f679fa583"
TREE = "7a4d47d5189d628b586f8765f9e6d1aafbb08aac"
BRANCH = "fix/n4-duration-controller-integration-rust-v14"
N3 = "d9c4944f382c6cff0167acc9a0dd5c2be3d8a31f"
N3_TREE = "ef34bcb57572cb970b3256334b7a60ecccf3d0be"
N3_BRANCH = "feat/behavior-intent-separation-rust-v12"
N3_EXE = "079ff02637bb7cb865b025c897732e74096bc04b9efd45ee50a8bb640dc06943"
DESKTOP_COMMIT = "01fff0664daa75d338d7b91c6e6517192e8c46d5"
DESKTOP_TREE = "de563e1e90c768fe5460c9b3f097aca798088cd0"
DESKTOP_EXE = "4be7169f5e593f3cf9be264ccd85e2c68f0eb1822e2566d10845f5e1a0c32023"
PARAMETER = "1c950fcbe0c4884e238f6279e10309b8810c6949d5610dfc4889d6c35252072b"
CONTROLLER = "n4-explicit-duration-engineering-v1"
PARAMETER_PATH = "crates/mechofly-core/parameters/n4-engineering-v1.json"
SCENARIOS = ("quiet_rest", "walking", "grooming", "repeated_loom", "mixed")
LABELS = {"rest": "Rest", "quiet": "Quiet", "walk": "Walk", "reverse": "Reverse",
          "groom": "Groom", "alert": "Alert", "pre_escape": "PreEscape",
          "flight": "Flight", "landing": "Landing"}
MINIMUM = {"rest": 30, "quiet": 20, "walk": 20, "reverse": 10,
           "groom": 46, "alert": 10, "pre_escape": 6, "flight": 121, "landing": 15}
VIOLATIONS = ("missed_loom_preemptions", "minimum_dwell_violations", "grooming_floor_violations",
              "periodic_schedule_events", "controller_faults")
FROZEN = ("crates/mechofly-app/src/pet.rs", "crates/mechofly-app/src/desktop_pet.rs",
          "crates/mechofly-app/src/shaders/neural_step.wgsl")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def no_duplicates(pairs: list) -> dict:
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result


def read_json(path: Path) -> dict:
    require(path.is_file() and path.stat().st_size <= 256 * 1024 * 1024,
            "Missing or oversized JSON: " + str(path))
    return json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=no_duplicates)


def save(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=True, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(tmp, path)


def compact(value: object) -> bytes:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def rust_hash(*parts: bytes) -> str:
    h = hashlib.sha256()
    for part in parts:
        h.update(len(part).to_bytes(8, "little"))
        h.update(part)
    return h.hexdigest()


def bin_name(ms: int) -> str:
    for threshold, name in ((100, "under_100_ms"), (250, "under_250_ms"),
                            (500, "under_500_ms"), (1000, "under_1_000_ms"),
                            (2000, "under_2_000_ms")):
        if ms < threshold:
            return name
    return "at_least_2_000_ms"


def regular(path: Path) -> bool:
    info = path.lstat()
    return not (stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400)


def inventory(root: Path) -> dict:
    if not root.exists():
        return {"exists": False, "files": {}}
    require(root.is_dir() and regular(root), "Reference directory is not ordinary: " + str(root))
    files = {}
    for directory, subdirs, names in os.walk(root, followlinks=False):
        for name in subdirs + names:
            p = Path(directory) / name
            require(regular(p), "Reparse point or symlink in evidence: " + str(p))
        for name in names:
            p = Path(directory) / name
            files[p.relative_to(root).as_posix()] = digest(p)
    return {"exists": True, "files": files}


def audit_campaign(directory: Path, authority: str, seeds: int, repeats: int, seconds: int) -> dict:
    """Independent accounting, raw event-chain and native signature audit.

    This checks emitted evidence. Eligible-loom *per-frame* completeness remains
    the Rust unit/campaign invariant; transition-only logs cannot re-prove it.
    """
    require(re.fullmatch(r"[0-9a-f]{64}", authority) is not None, "Invalid executable authority")
    c = read_json(directory / "campaign.json")
    require((c["schema_version"], c["controller"], c["parameter_sha256"], c["authority"],
             c["seeds"], c["repeats"], c["seconds"]) ==
            (1, CONTROLLER, PARAMETER, authority, seeds, repeats, seconds), "Campaign identity mismatch")
    require(c["controller_semantics_changed"] is True, "N4 must not claim N3 controller parity")
    expected = {(s, i, r) for s in SCENARIOS for i in range(seeds) for r in range(repeats)}
    require(len(c["runs"]) == len(expected), "Incomplete campaign matrix")
    seen, groups = set(), {}
    total_events = 0
    summaries = {s: {"frames": 0, "transitions": 0, "occupancy": collections.Counter()} for s in SCENARIOS}
    frames = (seconds * 1000 + 32) // 33
    for record in c["runs"]:
        d = record["deterministic"]
        key = (d["scenario"], d["seed_index"], record["repeat"])
        require(key in expected and key not in seen, "Unexpected or duplicate campaign run")
        seen.add(key)
        stem = f"{key[0]}-seed-{key[1]:02}-repeat-{key[2]}"
        require(read_json(directory / (stem + ".json")) == record, "Run file differs from campaign")
        require(record["schema_version"] == 1 and record["authority"] == authority
                and record["parameter_sha256"] == PARAMETER, "Run authority mismatch")
        require(d["model_seed"] == (0x7E1E0000 ^ key[1]) and d["frames"] == frames
                and d["modeled_ms"] == frames * 33, "Run seed or modeled duration mismatch")
        require(rust_hash(compact(d)) == record["deterministic_signature_sha256"], "Native signature mismatch")
        require(all(type(d[k]) is int and d[k] == 0 for k in VIOLATIONS), "Nonzero runtime violation")
        require(sum(d["occupancy_frames"].values()) == frames, "Occupancy accounting mismatch")
        require(d["retained_transition_count"] == min(d["transition_count"], 512)
                and d["dropped_transition_count"] == max(0, d["transition_count"] - 512), "Ring accounting mismatch")
        fc = d["final_controller"]
        require(fc["fault_latched"] is False and fc["parameter_sha256"] == PARAMETER
                and fc["last_frame"] == frames, "Final controller identity/fault mismatch")
        require(all(type(v) is int and 0 <= v <= 32767 for v in fc["context"].values()), "Unbounded final context")
        events = directory / (stem + ".events.jsonl")
        require(events.is_file() and regular(events) and digest(events) == d["raw_events_sha256"], "Raw event checksum mismatch")
        chain = rust_hash(b"mechofly-behavior-transition-stream-v1")
        current, last, first, count = "quiet", 0, 1, 0
        occupancy, reasons, bins = collections.Counter(), collections.Counter(), collections.Counter()
        with events.open("rb") as stream:
            for raw in stream:
                require(len(raw) <= 65536 and raw.endswith(b"\n"), "Malformed event line")
                event = json.loads(raw, object_pairs_hook=no_duplicates)
                f, details, intent = event["frame"], event["dynamics"], event["intent"]
                require(event["schema_version"] == 2 and event["sequence"] == count
                        and last < f <= frames and event["tick_ms"] == f * 33, "Event sequence/time mismatch")
                require(event["from_behavior"] == current and event["to_behavior"] in LABELS
                        and event["to_behavior"] != current, "Discontinuous behavior chain")
                elapsed = f - last
                require(event["elapsed_frames"] == elapsed and event["elapsed_ms"] == elapsed * 33,
                        "Event bout duration mismatch")
                require(details["parameter_sha256"] == PARAMETER and details["controller_sequence"] == count + 1,
                        "Missing controller provenance")
                require(details["from_substate"] in ("none", "settling")
                        and (details["from_substate"] != "settling" or current == "rest"), "Invalid settling provenance")
                minimum = 15 if details["from_substate"] == "settling" else MINIMUM[current]
                require(details["minimum_dwell_frames"] == minimum, "Incorrect declared dwell")
                require(type(event["emergency_override"]) is bool, "Invalid emergency flag")
                if event["emergency_override"]:
                    require(event["to_behavior"] == "pre_escape" and current not in ("pre_escape", "flight", "landing")
                            and intent["loom_activation_q15"] >= 5200, "Unsupported emergency exception")
                else:
                    require(elapsed >= minimum, "Premature ordinary exit")
                    require(current != "groom" or elapsed * 33 >= 1500, "Premature grooming exit")
                require(intent["autonomous_schedule_slot"] == 255 and intent["frame"] == f
                        and intent["current_behavior"] == current, "Legacy schedule or mismatched intent")
                require(event["reason"] != "legacy_autonomous_schedule", "Legacy schedule event")
                require(all(type(v) is int and 0 <= v <= 32767 for v in details["context"].values()), "Unbounded event context")
                if current in ("pre_escape", "flight", "landing"):
                    successor = {"pre_escape": "flight", "flight": "landing", "landing": "rest"}[current]
                    require(event["to_behavior"] == successor and elapsed == MINIMUM[current], "Airborne envelope mismatch")
                occupancy[LABELS[current]] += f - first
                reasons[event["reason"]] += 1
                bins[bin_name(elapsed * 33)] += 1
                chain = rust_hash(chain.encode("ascii"), compact(event))
                current, last, first, count = event["to_behavior"], f, f, count + 1
        occupancy[LABELS[current]] += frames - first + 1
        occupancy = +occupancy
        require(dict(occupancy) == d["occupancy_frames"] and dict(reasons) == d["transition_reasons"]
                and dict(bins) == d["bout_duration_bins"], "Raw event accounting disagrees with report")
        require(chain == d["transition_stream_sha256"] and count == d["transition_count"], "Event digest/count mismatch")
        require(fc["transition_sequence"] == count and fc["current_macro_state"] == current
                and fc["entered_at_frame"] == last and fc["elapsed_frames"] == frames - last,
                "Final controller does not continue the event chain")
        previous = groups.setdefault(key[:2], d)
        require(previous == d, "N4 repeats differ in deterministic fields")
        summary = summaries[key[0]]
        summary["frames"] += frames
        summary["transitions"] += count
        summary["occupancy"].update(occupancy)
        total_events += count
    require(seen == expected, "Missing scenario/seed/repeat")
    quiet = summaries["quiet_rest"]
    require(all(quiet["occupancy"][s] == 0 for s in ("PreEscape", "Flight", "Landing", "Reverse")), "Unsupported quiet escape/reverse")
    fraction = (quiet["occupancy"]["Quiet"] + quiet["occupancy"]["Rest"]) / quiet["frames"]
    require(fraction > 0.5, "Quiet context is not majority Quiet/Rest")
    return {"status": "PASS", "authority": authority, "parameter_sha256": PARAMETER,
            "runs": len(seen), "repeat_groups": len(groups), "events_audited": total_events,
            "seconds_per_run": seconds, "modeled_ms_per_run": frames * 33,
            "quiet_rest_fraction": fraction, "scenarios": summaries,
            "classification": "full_engineering_campaign" if (seeds, repeats, seconds) == (20, 2, 1800) else "smoke_only",
            "claim_boundary": "Synthetic Demo4096 CPU engineering invariants; not biological fit, GPU parity, visual acceptance or deployment"}


def git(root: Path, *arguments: str) -> str:
    env = os.environ.copy()
    env.update(GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0")
    p = subprocess.run(["git", "-C", str(root), *arguments], stdin=subprocess.DEVNULL,
                       capture_output=True, env=env, timeout=120)
    require(p.returncode == 0, "Git read failed: " + p.stderr.decode("utf-8", "replace"))
    return p.stdout.decode("utf-8").rstrip("\r\n")


def identity(root: Path) -> dict:
    return {"root": str(root), "branch": git(root, "branch", "--show-current"),
            "commit": git(root, "rev-parse", "HEAD"), "tree": git(root, "show", "-s", "--format=%T", "HEAD"),
            "status": git(root, "status", "--porcelain=v1", "--untracked-files=all"),
            "origin": git(root, "remote", "get-url", "origin")}


def snapshot(root: Path, desktop: Path, downloads: Path) -> dict:
    local, home = Path(os.environ["LOCALAPPDATA"]), Path(os.environ["USERPROFILE"])
    protected = [root / "host-windows/bin/MechoFly.exe", root / "host-windows/bin/MechoFly.pdb",
                 root / "artifacts/ai100-self-test.json", root / "artifacts/ai100-source-identity.json",
                 local / "MechoFly/runtime-profile.json", desktop / "host-windows/bin/DesktopFly.exe"]
    hashes = {str(p): digest(p) if p.is_file() else None for p in protected}
    shortcuts = {}
    for folder in {home / "Desktop", Path(os.environ.get("OneDrive", str(home / "OneDrive"))) / "Desktop",
                   Path(os.environ.get("PUBLIC", r"C:\Users\Public")) / "Desktop"}:
        for pattern in ("*MechoFly*.lnk", "*DesktopFly*.lnk"):
            for p in folder.glob(pattern):
                shortcuts[str(p)] = digest(p)
    references = {str(p): inventory(p) for p in (downloads / "MechoFly-D0-c06676c93085",
                  downloads / "MechoFly-N3-d9c4944f382c")}
    return {"n3": identity(root), "desktopfly": identity(desktop), "files": hashes,
            "shortcuts": shortcuts, "references": references}


def validate_baselines(before: dict, root: Path, desktop: Path) -> None:
    a, b = before["n3"], before["desktopfly"]
    require((a["branch"], a["commit"], a["tree"], a["status"]) == (N3_BRANCH, N3, N3_TREE, ""),
            "Canonical checkout is not the exact clean N3 baseline; no repair applied")
    require(before["files"][str(root / "host-windows/bin/MechoFly.exe")] == N3_EXE, "N3 executable differs; preserved")
    require((b["commit"], b["tree"], b["status"]) == (DESKTOP_COMMIT, DESKTOP_TREE, ""), "Frozen comparison identity differs; preserved")
    require(before["files"][str(desktop / "host-windows/bin/DesktopFly.exe")] == DESKTOP_EXE, "Frozen comparison executable differs; preserved")


class Lock:
    def __init__(self, path: Path):
        self.path, self.stream = path, None

    def __enter__(self):
        self.stream = self.path.open("a+b")
        if self.stream.tell() == 0:
            self.stream.write(b"0")
            self.stream.flush()
        self.stream.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.stream.close()
            self.stream = None
            raise RuntimeError("Another N4 validation owns this directory") from None
        return self

    def __exit__(self, *_):
        if self.stream:
            self.stream.close()


class Runner:
    def __init__(self, evidence: Path):
        self.evidence, self.steps = evidence, []

    def run(self, name: str, command: list[str], cwd: Path, env: dict, timeout: int = 7200) -> None:
        logs = self.evidence / "logs"
        logs.mkdir(exist_ok=True)
        print("N4_STEP=" + name, flush=True)
        start = time.monotonic()
        p = None
        error = None
        stdout, stderr = logs / (name + ".stdout.log"), logs / (name + ".stderr.log")
        try:
            with stdout.open("wb") as out, stderr.open("wb") as err:
                p = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                     creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
                heartbeat = 0.0
                while p.poll() is None:
                    elapsed = time.monotonic() - start
                    require(elapsed <= timeout, name + " timed out")
                    if elapsed >= heartbeat:
                        print(f"N4_HEARTBEAT step={name} seconds={elapsed:.0f} pid={p.pid}", flush=True)
                        # Display genuine completed-run progress, not guessed percentages.
                        with stdout.open("rb") as tail:
                            tail.seek(max(0, stdout.stat().st_size - 4096))
                            lines = tail.read().decode("utf-8", "replace").splitlines()
                        progress = [line for line in lines if line.startswith("N4_PROGRESS")]
                        if progress:
                            print(progress[-1], flush=True)
                        heartbeat += 15
                    time.sleep(0.25)
                require(p.returncode == 0, f"{name} exited {p.returncode}")
        except BaseException as exc:
            error = str(exc)
            raise
        finally:
            if p is not None and p.poll() is None:
                if os.name == "nt":
                    try:
                        subprocess.run(["taskkill.exe", "/PID", str(p.pid), "/T", "/F"], capture_output=True, timeout=30)
                    except (OSError, subprocess.TimeoutExpired):
                        p.kill()
                else:
                    p.kill()
                try:
                    p.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    p.kill()
                    p.wait(timeout=10)
            row = {"step": name, "command": command, "exit_code": p.returncode if p else None,
                   "seconds": time.monotonic() - start, "error": error}
            self.steps.append(row)
            save(logs / (name + ".process.json"), row)
            save(self.evidence / "steps.json", self.steps)
            if error and stderr.exists():
                with stderr.open("rb") as tail:
                    tail.seek(max(0, stderr.stat().st_size - 12000))
                    print(tail.read().decode("utf-8", "replace"), flush=True)
        print("N4_STEP_PASS=" + name, flush=True)


def prepare_source(stage: Path, run: Runner, env: dict) -> Path:
    owner = {"version": VERSION, "repository": REPOSITORY, "commit": CANDIDATE, "tree": TREE}
    marker = stage / "owner.json"
    if marker.exists():
        require(read_json(marker) == owner, "Existing stage is owned by another candidate; preserved")
    else:
        require(not any(p.name != ".lock" for p in stage.iterdir()), "Unowned stage is not empty; preserved")
        save(marker, owner)
    source = stage / "source"
    if not source.exists():
        source.mkdir()
    require(regular(source), "Source directory is redirected")
    if not (source / ".git").exists():
        require(not any(source.iterdir()), "Unowned source files would be overwritten")
        run.run("initialize-independent-clone", ["git", "init", str(source)], stage, env, 120)
        run.run("disable-crlf-conversion", ["git", "config", "core.autocrlf", "false"], source, env, 120)
        run.run("set-independent-origin", ["git", "remote", "add", "origin", REPOSITORY], source, env, 120)
    require((source / ".git").is_dir() and regular(source / ".git"), "Source must be an independent repository, not a linked worktree")
    require(git(source, "remote", "get-url", "origin").removesuffix(".git") == REPOSITORY.removesuffix(".git"), "Unexpected source origin")
    check = subprocess.run(["git", "-C", str(source), "rev-parse", "--verify", "HEAD"], capture_output=True, env=env, timeout=30)
    if check.returncode:
        require(all(p.name == ".git" for p in source.iterdir()), "Partial checkout contains files; preserved")
        run.run("fetch-published-exact-source", ["git", "fetch", "--no-tags", "origin", CANDIDATE], source, env, 300)
        run.run("checkout-published-exact-source", ["git", "checkout", "--detach", CANDIDATE], source, env, 120)
    verify_source(source)
    return source


def verify_source(source: Path) -> None:
    require(git(source, "rev-parse", "HEAD") == CANDIDATE and git(source, "show", "-s", "--format=%T", "HEAD") == TREE,
            "Candidate commit/tree mismatch; no reset or patch attempted")
    require(git(source, "status", "--porcelain=v1", "--untracked-files=all") == "", "Candidate source has edits; preserved")
    require(digest(source / PARAMETER_PATH) == PARAMETER, "Parameter bytes differ from the validated artifact")
    for relative in FROZEN:
        require(git(source, "rev-parse", f"{N3}:{relative}") == git(source, "rev-parse", f"HEAD:{relative}"),
                "Frozen renderer/shader changed: " + relative)


def safe_stage(stage: Path, *protected: Path) -> None:
    for path in protected:
        require(stage != path and path not in stage.parents and stage not in path.parents,
                "Validation and protected directories overlap")
    for p in (stage, *stage.parents):
        if p.exists():
            require(regular(p), "Validation path crosses a symlink/junction: " + str(p))


def seal(evidence: Path, destination: Path) -> None:
    files = inventory(evidence)["files"]
    files.pop("SHA256SUMS.json", None)
    save(evidence / "SHA256SUMS.json", files)
    with zipfile.ZipFile(destination, "x", zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(evidence.rglob("*")):
            if p.is_file():
                archive.write(p, p.relative_to(evidence).as_posix())
    with zipfile.ZipFile(destination) as archive:
        require(archive.testzip() is None, "Evidence ZIP CRC failure")


def execute(args: argparse.Namespace) -> int:
    require(os.name == "nt", "AI100 validation requires Windows; audit and unit tests are portable")
    root, desktop = Path(args.repository_root).resolve(), Path(args.desktopfly_root).resolve()
    downloads = Path(os.environ["USERPROFILE"]) / "Downloads"
    stage = root.parent / "MechoFly-N4-Validation" / (CANDIDATE[:12] + "-exact-v2")
    safe_stage(stage, root, desktop, downloads)
    evidence = downloads / ("MechoFly-N4-ExactValidation-" + stamp())
    evidence.mkdir(parents=True)
    run, before = Runner(evidence), None
    result = {"schema_version": 1, "runner": VERSION, "status": "RUNNING", "candidate_commit": CANDIDATE,
              "candidate_tree": TREE, "candidate_branch": BRANCH, "canonical_deployment": False,
              "old_d0_or_n3_rerun": False, "visual_acceptance": "NOT_RECORDED", "stage": str(stage)}
    try:
        print(f"MECHOFLY_N4_EXACT=START\nEVIDENCE_ROOT={evidence}\nCANDIDATE_COMMIT={CANDIDATE}", flush=True)
        for tool in ("git", "cargo"):
            require(shutil.which(tool) is not None, tool + " is not on PATH")
        before = snapshot(root, desktop, downloads)
        save(evidence / "identity-before.json", before)
        validate_baselines(before, root, desktop)
        stage.mkdir(parents=True, exist_ok=True)
        with Lock(stage / ".lock"):
            env = os.environ.copy()
            env.update(GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0", CARGO_TERM_COLOR="never", PYTHONDONTWRITEBYTECODE="1")
            source = prepare_source(stage, run, env)
            env["CARGO_TARGET_DIR"] = str(source / "target")
            run.run("archive-exact-source", ["git", "archive", "--format=zip", "--output", str(evidence / "candidate-source.zip"), CANDIDATE], source, env, 120)
            run.run("verify-real-n4-integration", [sys.executable, "tools/verify_n4_integration.py"], source, env, 120)
            run.run("rust-format-check", ["cargo", "fmt", "--all", "--check"], source, env, 120)
            run.run("n4-controller-tests", ["cargo", "test", "--release", "--locked", "-p", "mechofly-core", "--test", "n4_dynamics", "--", "--nocapture"], source, env)
            log = (evidence / "logs/n4-controller-tests.stdout.log").read_text(encoding="utf-8", errors="replace")
            require(re.search(r"test result: ok\. 7 passed; 0 failed;", log) is not None, "Expected seven N4 tests did not execute")
            (evidence / "visual-fixtures").mkdir(exist_ok=True)
            env["MECHOFLY_VISUAL_FIXTURE_DIR"] = str(evidence / "visual-fixtures")
            run.run("workspace-tests", ["cargo", "test", "--release", "--locked", "--workspace", "--", "--nocapture"], source, env)
            run.run("warnings-denied-clippy", ["cargo", "clippy", "--workspace", "--all-targets", "--locked", "--", "-D", "warnings"], source, env)
            run.run("release-build", ["cargo", "build", "--release", "--locked", "-p", "mechofly-app"], source, env)
            exe = source / "target/release/MechoFly.exe"
            require(exe.is_file(), "Rust release executable was not produced")
            authority = digest(exe)
            result["executable_sha256"] = authority
            result["executable_path"] = str(exe)
            isolated = stage / "isolated-local-appdata" / authority[:16]
            isolated.mkdir(parents=True, exist_ok=True)
            profile = read_json(Path(os.environ["LOCALAPPDATA"]) / "MechoFly/runtime-profile.json")
            profile.update(source_branch=BRANCH, source_commit=CANDIDATE, source_tree=TREE, executable_sha256=authority)
            save(isolated / "MechoFly/runtime-profile.json", profile)
            save(evidence / "isolated-runtime-profile.json", profile)
            native_env = env.copy()
            native_env["LOCALAPPDATA"] = str(isolated)
            run.run("native-self-test", [str(exe), "--self-test", str(evidence / "self-test.json")], source, native_env, 180)
            receipt = read_json(evidence / "self-test.json")
            require(receipt.get("schema_version") == 10 and receipt.get("status") == "PASS"
                    and receipt.get("runtime_behavior_controller") == CONTROLLER
                    and receipt.get("n4", {}).get("passed") is True
                    and receipt["n4"]["parameter_sha256"] == PARAMETER, "Executable lacks validated N4 runtime receipt")
            seeds, repeats, seconds = (20, 2, 1800) if args.full_campaign else (2, 2, 30)
            campaign = stage / "campaigns" / authority / ("full" if args.full_campaign else "smoke")
            command = [str(exe), "--behavior-campaign", str(campaign), "--campaign-authority", authority,
                       "--campaign-seeds", str(seeds), "--campaign-repeats", str(repeats), "--campaign-seconds", str(seconds)]
            run.run("n4-full-campaign" if args.full_campaign else "n4-smoke-campaign", command, source, native_env, 14400)
            result["campaign"] = audit_campaign(campaign, authority, seeds, repeats, seconds)
            # Resume must reuse completed runs with zero byte changes.
            original = inventory(campaign)
            run.run("completed-run-resume", command, source, native_env, 600)
            require(inventory(campaign) == original, "Completed-run resume changed campaign bytes")
            result["completed_resume_byte_equal"] = True
            save(evidence / "campaign-audit.json", result["campaign"])
            shutil.copytree(campaign, evidence / "n4-campaign")
            shutil.copyfile(source / PARAMETER_PATH, evidence / "n4-engineering-v1.json")
            if args.capture_gui:
                ps = str(Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe")
                prefix = [ps, "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File"]
                run.run("isolated-gui", prefix + [str(source / "tools/Test-Windows-GuiStartup.ps1"), "-ExecutablePath", str(exe),
                        "-OutputDirectory", str(evidence / "runtime-smoke"), "-ObservationSeconds", "12"], source, native_env, 300)
                run.run("isolated-pet-topmost", prefix + [str(source / "tools/Test-Windows-PetTopmost.ps1"), "-ExecutablePath", str(exe),
                        "-ReceiptPath", str(evidence / "pet-topmost.json"), "-ObservationSeconds", "12"], source, native_env, 300)
                gui, top = read_json(evidence / "runtime-smoke/summary.json"), read_json(evidence / "pet-topmost.json")
                require(gui.get("status") == "PASS" and top.get("status") == "PASS"
                        and top.get("desktop_pet_topmost") is True and top.get("desktop_pet_above_brain_lab") is True,
                        "Local GUI/topmost validation failed")
                result["gui_validation"] = "PASS_CAPTURE_REQUIRES_VISUAL_REVIEW"
            else:
                result["gui_validation"] = "NOT_RUN"
            verify_source(source)
            require(digest(exe) == authority, "Candidate executable changed during validation")
            after = snapshot(root, desktop, downloads)
            save(evidence / "identity-after.json", after)
            require(before == after, "Protected N3/desktop/evidence identity changed; no deployment permitted")
            result.update(status="PASS", canonical_n3_unchanged=True, desktopfly_unchanged=True, reference_evidence_unchanged=True)
            save(evidence / "manifest.json", result)
            destination = downloads / ("UPLOAD_MechoFly_N4_ExactValidation_" + stamp() + ".zip")
            seal(evidence, destination)
            print(f"MECHOFLY_N4_EXACT=PASS\nCANONICAL_N3_UNCHANGED=True\nDESKTOPFLY_UNCHANGED=True\nOLD_D0_RERUN=False\nN4_DEPLOYED=False\nVISUAL_ACCEPTANCE=PENDING\nEVIDENCE_ZIP={destination}", flush=True)
            return 0
    except BaseException as exc:
        result.update(status="FAIL", error=str(exc), exception_type=type(exc).__name__, steps=run.steps)
        if before is not None:
            try:
                after = snapshot(root, desktop, downloads)
                save(evidence / "identity-after-failure.json", after)
                result["canonical_and_reference_unchanged"] = after == before
            except Exception as check:
                result["preservation_check_error"] = str(check)
        save(evidence / "failure.json", result)
        destination = downloads / ("UPLOAD_MechoFly_N4_ExactValidation_DIAGNOSTIC_" + stamp() + ".zip")
        try:
            seal(evidence, destination)
            print("DIAGNOSTIC_ZIP=" + str(destination), flush=True)
        except Exception as sealing:
            print(f"DIAGNOSTIC_ROOT={evidence}\nDIAGNOSTIC_SEAL_ERROR={sealing}", flush=True)
        print("MECHOFLY_N4_EXACT=FAIL\nERROR=" + str(exc), flush=True)
        return 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository-root", default=r"D:\Projects\MechoFly")
    parser.add_argument("--desktopfly-root", default=r"D:\Projects\DesktopFly-V12")
    parser.add_argument("--full-campaign", action="store_true")
    parser.add_argument("--capture-gui", action="store_true")
    parser.add_argument("--audit-campaign", type=Path)
    parser.add_argument("--authority")
    parser.add_argument("--audit-output", type=Path)
    args = parser.parse_args()
    if args.audit_campaign:
        require(args.authority is not None, "--authority is required for an independent audit")
        config = (20, 2, 1800) if args.full_campaign else (2, 2, 30)
        report = audit_campaign(args.audit_campaign, args.authority, *config)
        if args.audit_output:
            save(args.audit_output, report)
        print(json.dumps(report, indent=2), flush=True)
        return 0
    return execute(args)


if __name__ == "__main__":
    sys.exit(main())

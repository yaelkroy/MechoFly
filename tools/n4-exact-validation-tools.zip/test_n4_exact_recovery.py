"""Offline regression tests. Synthetic fixtures are not controller evidence."""
import contextlib
import copy
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import n4_exact_recovery as m


def fixture(root):
    authority = 'a' * 64
    runs = []
    for scenario in m.SCENARIOS:
        for seed in range(2):
            for repeat in range(2):
                d = {
                    'scenario': scenario, 'seed_index': seed, 'model_seed': 0x7E1E0000 ^ seed,
                    'frames': 910, 'modeled_ms': 30030,
                    'occupancy_frames': {'Quiet': 910}, 'transition_count': 0,
                    'retained_transition_count': 0, 'dropped_transition_count': 0,
                    'transition_reasons': {}, 'bout_duration_bins': {},
                    'final_controller': {'fault_latched': False, 'parameter_sha256': m.PARAMETER,
                                         'last_frame': 910, 'context': {'arousal_q15': 0},
                                         'transition_sequence': 0, 'current_macro_state': 'quiet',
                                         'entered_at_frame': 0, 'elapsed_frames': 910},
                    'transition_stream_sha256': m.rust_hash(b'mechofly-behavior-transition-stream-v1'),
                    'raw_events_sha256': m.hashlib.sha256(b'').hexdigest(),
                    **{k: 0 for k in m.VIOLATIONS},
                }
                record = {'schema_version': 1, 'authority': authority, 'parameter_sha256': m.PARAMETER,
                          'repeat': repeat, 'deterministic': d, 'deterministic_signature_sha256': m.rust_hash(m.compact(d))}
                stem = f'{scenario}-seed-{seed:02}-repeat-{repeat}'
                m.save(root / (stem + '.json'), record)
                (root / (stem + '.events.jsonl')).write_bytes(b'')
                runs.append(record)
    c = {'schema_version': 1, 'controller': m.CONTROLLER, 'parameter_sha256': m.PARAMETER,
         'authority': authority, 'seeds': 2, 'repeats': 2, 'seconds': 30,
         'controller_semantics_changed': True, 'runs': runs}
    m.save(root / 'campaign.json', c)
    return c


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.c = fixture(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def audit(self):
        return m.audit_campaign(self.root, 'a' * 64, 2, 2, 30)

    def update(self):
        m.save(self.root / 'campaign.json', self.c)

    def resign(self, record):
        d = record['deterministic']
        record['deterministic_signature_sha256'] = m.rust_hash(m.compact(d))
        m.save(self.root / f"{d['scenario']}-seed-{d['seed_index']:02}-repeat-{record['repeat']}.json", record)
        self.update()

    def test_accounting_fixture_passes(self):
        a = self.audit()
        self.assertEqual((a['runs'], a['repeat_groups'], a['events_audited']), (20, 10, 0))
        self.assertEqual(a['classification'], 'smoke_only')

    def test_wrong_authority_rejected(self):
        with self.assertRaises(RuntimeError):
            m.audit_campaign(self.root, 'b' * 64, 2, 2, 30)

    def test_missing_run_rejected(self):
        self.c['runs'].pop(); self.update()
        with self.assertRaises(RuntimeError): self.audit()

    def test_duplicate_run_rejected(self):
        self.c['runs'][-1] = copy.deepcopy(self.c['runs'][0]); self.update()
        with self.assertRaises(RuntimeError): self.audit()

    def test_forged_run_signature_rejected(self):
        r = self.c['runs'][0]; r['deterministic_signature_sha256'] = 'f' * 64
        m.save(self.root / 'quiet_rest-seed-00-repeat-0.json', r); self.update()
        with self.assertRaises(RuntimeError): self.audit()

    def test_modified_event_bytes_rejected(self):
        (self.root / 'quiet_rest-seed-00-repeat-0.events.jsonl').write_text('{}\n')
        with self.assertRaises(RuntimeError): self.audit()

    def test_passing_flags_cannot_hide_runtime_violation(self):
        r = self.c['runs'][0]; r['deterministic']['minimum_dwell_violations'] = 1; self.resign(r)
        with self.assertRaises(RuntimeError): self.audit()

    def test_bool_is_not_integer_violation_count(self):
        r = self.c['runs'][0]; r['deterministic']['controller_faults'] = False; self.resign(r)
        with self.assertRaises(RuntimeError): self.audit()

    def test_invalid_final_context_rejected(self):
        r = self.c['runs'][0]; r['deterministic']['final_controller']['context']['arousal_q15'] = 32768; self.resign(r)
        with self.assertRaises(RuntimeError): self.audit()

    def test_changed_repeat_rejected(self):
        r = self.c['runs'][1]; r['deterministic']['final_controller']['context']['arousal_q15'] = 1; self.resign(r)
        with self.assertRaises(RuntimeError): self.audit()

    def test_forged_occupancy_rejected(self):
        r = self.c['runs'][0]; r['deterministic']['occupancy_frames'] = {'Rest': 910}; self.resign(r)
        with self.assertRaises(RuntimeError): self.audit()

    def test_duplicate_json_rejected(self):
        (self.root / 'campaign.json').write_text('{"status":0,"status":1}')
        with self.assertRaises(RuntimeError): m.read_json(self.root / 'campaign.json')

    def test_full_campaign_cannot_use_smoke_receipt(self):
        with self.assertRaises(RuntimeError): m.audit_campaign(self.root, 'a' * 64, 20, 2, 1800)


class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()

    def tearDown(self):
        self.temp.cleanup()

    def test_sibling_directory_is_separate(self):
        m.safe_stage(self.root / 'MechoFly-N4', self.root / 'MechoFly')

    def test_overlapping_directory_rejected(self):
        for stage in (self.root, self.root / 'MechoFly', self.root / 'MechoFly/nested'):
            with self.assertRaises(RuntimeError): m.safe_stage(stage, self.root / 'MechoFly')

    def test_lock_contention_and_release(self):
        lock = self.root / '.lock'
        with m.Lock(lock):
            with self.assertRaises(RuntimeError):
                with m.Lock(lock): pass
        with m.Lock(lock): pass

    def test_reference_byte_change_detected(self):
        p = self.root / 'reference'; p.mkdir(); (p / 'one').write_text('one')
        before = m.inventory(p); (p / 'one').write_text('two')
        self.assertNotEqual(before, m.inventory(p))

    def test_symlink_evidence_rejected(self):
        target = self.root / 'target'; target.write_text('important')
        link = self.root / 'link'
        try: link.symlink_to(target)
        except OSError: self.skipTest('symlink creation unavailable')
        with self.assertRaises(RuntimeError): m.inventory(self.root)

    def test_unowned_stage_is_preserved(self):
        (self.root / 'foreign.txt').write_text('keep')
        with self.assertRaises(RuntimeError): m.prepare_source(self.root, m.Runner(self.root), os.environ.copy())
        self.assertEqual((self.root / 'foreign.txt').read_text(), 'keep')

    def test_wrong_owner_is_preserved(self):
        m.save(self.root / 'owner.json', {'commit': 'another'})
        before = m.digest(self.root / 'owner.json')
        with self.assertRaises(RuntimeError): m.prepare_source(self.root, m.Runner(self.root), os.environ.copy())
        self.assertEqual(before, m.digest(self.root / 'owner.json'))

    def test_native_success_can_write_stderr(self):
        run = m.Runner(self.root)
        with contextlib.redirect_stdout(io.StringIO()):
            run.run('stderr-ok', [sys.executable, '-c', 'import sys;sys.stderr.write("not a failure\\n")'], self.root, os.environ.copy(), 5)
        self.assertEqual(run.steps[-1]['exit_code'], 0)

    def test_actual_native_nonzero_exit_is_rejected(self):
        run = m.Runner(self.root)
        with contextlib.redirect_stdout(io.StringIO()), self.assertRaises(RuntimeError):
            run.run('bad-exit', [sys.executable, '-c', 'raise SystemExit(7)'], self.root, os.environ.copy(), 5)
        self.assertEqual(run.steps[-1]['exit_code'], 7)
        self.assertTrue((self.root / 'steps.json').is_file())

    def test_owned_process_timeout_is_recorded(self):
        run = m.Runner(self.root)
        with contextlib.redirect_stdout(io.StringIO()), self.assertRaises(RuntimeError):
            run.run('timeout', [sys.executable, '-c', 'import time;time.sleep(10)'], self.root, os.environ.copy(), 0.1)
        self.assertIsNotNone(run.steps[-1]['exit_code'])
        self.assertIn('timed out', run.steps[-1]['error'])

    def test_git_status_leading_whitespace_is_preserved(self):
        subprocess.run(['git', 'init', str(self.root)], capture_output=True, check=True)
        (self.root / 'one').write_text('one')
        subprocess.run(['git', '-C', str(self.root), 'add', 'one'], check=True)
        subprocess.run(['git', '-C', str(self.root), '-c', 'user.name=test', '-c', 'user.email=test@example.invalid',
                        'commit', '-m', 'test'], capture_output=True, check=True)
        (self.root / 'one').write_text('changed')
        self.assertTrue(m.git(self.root, 'status', '--porcelain=v1').startswith(' M'))

    def test_sealed_archive_matches_inventory(self):
        evidence = self.root / 'evidence'; evidence.mkdir(); (evidence / 'test.txt').write_text('source')
        m.seal(evidence, self.root / 'out.zip')
        with m.zipfile.ZipFile(self.root / 'out.zip') as archive:
            self.assertIsNone(archive.testzip())
            values = json.loads(archive.read('SHA256SUMS.json'))
            self.assertEqual(values['test.txt'], m.hashlib.sha256(archive.read('test.txt')).hexdigest())


if __name__ == '__main__':
    unittest.main(verbosity=2)
